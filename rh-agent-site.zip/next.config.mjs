import withNextra from 'nextra' assert { type: 'function' }

const withDocs = withNextra({
  theme: 'nextra-theme-docs',
  themeConfig: './theme.config.jsx',
})

export default withDocs({
  reactStrictMode: true
})